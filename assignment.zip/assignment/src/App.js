//import logo from './logo.svg';
import './App.css';
import List from './List';
import {items} from './Demo';

function App() {
  return (
<>
    <List items={items}/>
    
</> 
  );
}

export default App;
